/**
 * 
 */
package lab3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;




/**
 * @author dmaldonado
 *
 */
public class Startup 
{
	public static class CompareContactName implements Comparator<Contact>
	{
		@Override
		public int compare(Contact c1, Contact c2)
		{
			if(c1 == null || c2 == null || c1.getClass() != c2.getClass())
			{
				return -1;
			}

			return c1.name.compareTo(c2.name);
		}
	}

	public static class CompareContactPhone implements Comparator<Contact>
	{
		@Override
		public int compare(Contact c1, Contact c2)
		{
			if(c1 == null || c2 == null || c1.getClass() != c2.getClass())
			{
				return -1;
			}

			return c1.phoneNr.compareTo(c2.phoneNr);
		}
	}

	public static class CompareContactEmail implements Comparator<Contact>
	{
		@Override
		public int compare(Contact c1, Contact c2)
		{
			if(c1 == null || c2 == null || c1.getClass() != c2.getClass())
			{
				return -1;
			}

			return c1.email.compareTo(c2.email);
		}
	}

	public static class CompareContactBirth implements Comparator<Contact>
	{
		@Override
		public int compare(Contact c1, Contact c2)
		{
			if(c1 == null || c2 == null || c1.getClass() != c2.getClass())
			{
				return -1;
			}

			return c1.birthDate.compareTo(c2.birthDate);
		}
	}

	public class Contact implements Comparable<Contact>
	{
		String name;
		String phoneNr;
		String email;
		String birthDate;
		/* (non-Javadoc)
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode() 
		{
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			result = prime * result
					+ ((birthDate == null) ? 0 : birthDate.hashCode());
			result = prime * result + ((email == null) ? 0 : email.hashCode());
			result = prime * result + ((name == null) ? 0 : name.hashCode());
			result = prime * result
					+ ((phoneNr == null) ? 0 : phoneNr.hashCode());
			return result;
		}
		/* (non-Javadoc)
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(Object obj) 
		{
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Contact other = (Contact) obj;
			if (!getOuterType().equals(other.getOuterType()))
				return false;
			if (birthDate == null) {
				if (other.birthDate != null)
					return false;
			} else if (!birthDate.equals(other.birthDate))
				return false;
			if (email == null) {
				if (other.email != null)
					return false;
			} else if (!email.equals(other.email))
				return false;
			if (name == null) {
				if (other.name != null)
					return false;
			} else if (!name.equals(other.name))
				return false;
			if (phoneNr == null) {
				if (other.phoneNr != null)
					return false;
			} else if (!phoneNr.equals(other.phoneNr))
				return false;
			return true;
		}

		private Startup getOuterType() 
		{
			return Startup.this;
		}

		@Override
		public int compareTo(Contact o) {
			// TODO Auto-generated method stub
			return 0;
		}
	}
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception
	{
		System.out.println("Menu");

		HashMap<Contact,Integer> tree = new HashMap<>();
		FileReader file = new FileReader("Contacts.csv");
		BufferedReader buff = new BufferedReader(file);
		int counter = 0;

		String line = "";
		while(buff.ready())
		{
			line = buff.readLine();
			tree[counter] = line;
			counter++;
		}

	}

	public static void menu() throws Exception
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("What do you want to do?\n1)Print persons sorted by Name\n2)Print persons sorted by Phone Number\n3)Print persons sorted by Email Address\n4)Print persons sorted by Birth Date\n5)Get a single person by Name\n6)Quit");
		switch(scan.nextInt())
		{
		case 1:
		{
			sortName();
		}
		case 2:
		{
			sortPhone();
		}
		case 3:
		{
			sortEmail();
		}
		case 4:
		{
			sortBirth();
		}
		case 5:
		{
			singlePerson();
		}
		case 6:
		{
			scan.close();
			quit();
		}
		}
	}
	public static void quit()
	{
		System.out.println("Goodbye.");
	}

	public static void singlePerson() throws IOException
	{
		Scanner scan = new Scanner(System.in);
		FileReader input = new FileReader("Contacts.csv");
		BufferedReader buffer = new BufferedReader(input);
		String line = "";
		System.out.println("Enter the name of the contact");
		while(buffer.ready())
		{
			line = buffer.readLine();
			String name = scan.next();
			Pattern pattern = Pattern.compile("(["+name+"])[(][0-9]+[)][ ][0-9]+[-][[0-9]+][a-zA-Z0-9]+[@][a-zA-Z]+[.com]+");
			Matcher matcher = pattern.matcher(line);
			while(matcher.find())
			{
				System.out.println(line);
			}
		}
		try 
		{
			menu();
		} 
		catch (Exception e) 
		{
			System.err.println("Error has occurred");
		}
		finally
		{
			scan.close();
			buffer.close();
		}
	}

	public static void sortName() throws Exception
	{
		ArrayList<Contact> tree = new ArrayList<>();
		FileReader file = new FileReader("Contacts.csv");
		BufferedReader buff = new BufferedReader(file);
		int counter = 0;

		String line = "";
		while(buff.ready())
		{
			line = buff.readLine();
			tree[counter] = line;
			counter++;
		}
		Collections.sort(tree, new CompareContactName());

		for(Contact c : tree)
		{
			System.out.println(c.name);
		}
		try 
		{
			menu();
		} 
		catch (Exception e) 
		{
			System.err.println("Error has occurred");
		}
	}

	public static void sortPhone() throws Exception
	{
		ArrayList<Contact> tree = new ArrayList<>();
		FileReader file = new FileReader("Contacts.csv");
		BufferedReader buff = new BufferedReader(file);
		int counter = 0;

		String line = "";
		while(buff.ready())
		{
			line = buff.readLine();
			tree[counter] = line;
			counter++;
		}
		Collections.sort(tree, new CompareContactPhone());

		for(Contact c : tree)
		{
			System.out.println(c.phoneNr);
		}
		try 
		{
			menu();
		} 
		catch (Exception e) 
		{
			System.err.println("Error has occurred");
		}
	}

	public static void sortEmail() throws Exception
	{
		ArrayList<Contact> tree = new ArrayList<>();
		FileReader file = new FileReader("Contacts.csv");
		BufferedReader buff = new BufferedReader(file);
		int counter = 0;

		String line = "";
		while(buff.ready())
		{
			line = buff.readLine();
			tree[counter] = line;
			counter++;
		}
		Collections.sort(tree, new CompareContactEmail());

		for(Contact c : tree)
		{
			System.out.println(c.name);
		}
		try 
		{
			menu();
		} 
		catch (Exception e) 
		{
			System.err.println("Error has occurred");
		}
	}

	public static void sortBirth() throws Exception
	{
		ArrayList<Contact> tree = new ArrayList<>();
		FileReader file = new FileReader("Contacts.csv");
		BufferedReader buff = new BufferedReader(file);
		int counter = 0;

		String line = "";
		while(buff.ready())
		{
			line = buff.readLine();
			tree[counter] = line;
			counter++;
		}
		Collections.sort(tree, new CompareContactBirth());

		for(Contact c : tree)
		{
			System.out.println(c.name);
		}
		try 
		{
			menu();
		} 
		catch (Exception e) 
		{
			System.err.println("Error has occurred");
		}
	}
}