package chat;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Server 
{

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		ServerChat server = new ServerChat(false);
		server.redirect();
	}
}